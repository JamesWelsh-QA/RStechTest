class PLP {

    constructor (page)
    {
        this.page = page;

    }

}

module.exports = {PLP};